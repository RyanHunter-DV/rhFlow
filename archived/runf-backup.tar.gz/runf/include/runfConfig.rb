require 'optparse';




class RunfConfig ## {

	def initialize ## {
		@optParser = OptionParser.new();
	end ## }

end ## }
