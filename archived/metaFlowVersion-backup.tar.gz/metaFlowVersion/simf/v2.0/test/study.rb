a = [1,2];
puts a.methods
