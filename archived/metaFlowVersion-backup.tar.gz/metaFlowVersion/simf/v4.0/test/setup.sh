export PROJECT_ROOT='./'
export SIMF_ENTRY='./root.rh'
export SIMF_CONTEXT='testContext'

