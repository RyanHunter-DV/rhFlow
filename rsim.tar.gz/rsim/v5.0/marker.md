# Description
This markdown file: marker is used to record daily coding progress. Used for fast remembering.
# 20230709
[./src/core.rb](core), test marker
# 20230710
 [./src/MessagePrinter.rb](MessagePrinter), next to test the MessagePrinter
# 20230711
- [ ] [[./src/UserInterface.rb]], need a test, to test current existing APIs.
# 20230712
# 20230713
- plan for build flow, use freeform

