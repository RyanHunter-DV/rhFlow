The Rsim tool provides users an option to build the target files and filelist by using the `-b` option.
By specifying the `-b` option with the config name, can build a certain toolchains and target files for next step, such as EDA compiling.
# Build a certain config
#TBD 
# Build multiple configs
#TBD 
