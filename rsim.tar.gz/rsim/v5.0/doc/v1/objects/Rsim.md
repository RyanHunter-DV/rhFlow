A central module used as the global namespace
# Public apis
## Rsim.mp
The message printer, can be called by other components after the initial setup, to debug or info messages.
## Rsim.register
To register ipxact metadata to the central place, so that it can be easily controlled and used.

## Rsim.start
