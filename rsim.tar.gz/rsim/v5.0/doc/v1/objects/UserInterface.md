# class UserInterface
## Public apis
### setupNodeStep
To setup rhload steps with initial nodes.