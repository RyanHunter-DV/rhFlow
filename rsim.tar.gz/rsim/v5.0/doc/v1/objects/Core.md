# class Core
## Public apis
### new
1. setup steps
2. run steps
