require 'PoolBase'
class ComponentPool

	def initialize ##{{{
		super;
	end ##}}}
public
	## place public methods here
private
	## place private methods here
end