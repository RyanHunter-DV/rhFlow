"""
# Description
MetaData,this is the database where all ip-xact database located
"""
class MetaData
	def initialize ##{{{
	end ##}}}
public
	## place public methods here
private
	## place private methods here
end