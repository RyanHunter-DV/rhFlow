The common lib for all rhFlow tool, this can be a symbol link if the lib is more common in all ruby programs.
*Note*
This copies from the ~/rhFlow/libs temporary for windows test.