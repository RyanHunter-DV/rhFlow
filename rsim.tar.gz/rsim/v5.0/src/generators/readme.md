# Overall
The generator dir, stores all different generators
# generator flow
- created by user component nodes, while calling `generator 'name'...` in user block, can build a new generator for certain component
- if call the component.generator without any args, then return the defined generator.