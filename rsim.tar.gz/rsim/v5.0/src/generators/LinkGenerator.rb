require 'generators/GeneratorBase'
class LinkGenerator < GeneratorBase

	def initialize(old=nil) ##{{{
		super('LinkGenerator',old);
	end ##}}}
public
	## place public methods here
private
	## place private methods here
end